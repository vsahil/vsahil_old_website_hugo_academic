#!/usr/bin/env bash

hugo server --disableFastRender --i18n-warnings
